function Step2_Recon3D(datafolder,mindist_2D,mindist_3D,minSepDist_3D)
% Step2_Recon3D: reconstruct 3D positions of birds from the multiple 2D measurements 
%
% Features: solving optical occlusions frame by frame
%      
% Algorithm: two particles overlap in view 1 will separated in view 3,
% giving that view 1 and 3 have very different viewing angle
%      Step 1: search all particle in view 1 and find their best matches,
%      and reconstruct their 3D position 
%      Step 2: search particles in view 3 that have not been matched in Step 1,
%              and find their matches, and reconstruct their 3D position 
%      Step 3: combine the 3D positions obtained from Step 1 and 2
%
% Input parameters
%     datafolder - the name of folder containing lists of particles generated 
%                  from 'Step1_BirdDetection.m'
%     mindist_2D - tolerance of particle and epi-polar line distance, unit pixel
%                  eg. 5 or 15 pixels
%     mindist_3D - tolerance of nearby epi-polar lines distance, unit m
%                  eg. 0.5 m, which is about the size of bird
%     minSepDist_3D - min separation distance between 2 particle (unit m)
%                  eg. 0.5 m, based on the reality that two birds can not
%                  be very close
%
% Output files:
%     list of particle 3d position save in nx4 array in *.dat file
%     results are stored at the same folder where the data are stored
%     The output files will be used for tracking
%
% Example: 
%    Step2_Recon3D('Data_raw/',10,0.5,0.5);
%
% Other m-files required: none
% Subfunctions: dlt_image2ray, dlt_world2image, dlt_image2world
% MAT-files required: camera parameters represented by 11 coefficients obtained
% by directly linear transformation, for more details of camera
% calibration, refer to: 
%   'Theriault, et al. (2014). A protocol and calibration method for 
%    accurate multi-camera field videography. Journal of Experimental Biology, 
%    217(11), 1843-1848. doi:10.1242/jeb.100529'
%
% Author: Hangjian Ling, Postdoc, Stanford University
%         Nicholas Ouellette, Stanford University
% email address: linghj@stanford.edu; nto@stanford.edu
%
% May 2018; Last revision: May-14-2018


%%%% load camera parameters for each camera
load([datafolder,'camcoefs.mat']); %% camera parameters: coef(1:11,view)
%%%% load lists of particle 2D positions generated from step 1
nCam=size(coefs,2);
Par2Dfile{1} = [datafolder,'particle2Dlist_1.mat'];
Par2Dfile{2} = [datafolder,'particle2Dlist_2.mat'];
Par2Dfile{3} = [datafolder,'particle2Dlist_3.mat'];
Par2Dfile{4} = [datafolder,'particle2Dlist_4.mat'];
for i=1:nCam
    Par2D{i}=load(Par2Dfile{i});
end
%%%% Output file name of the 3D reconstruction result
Particle3DFile = [datafolder,'particle3Dlist.dat'];

%%%%%%%%%%%%%% Start
XYZt=[]; %%% initia. the particle 3D list
% Bg_pts=[]; %%% initia. the corresponding pixels cross views, use it to correct the calibration
Frames=unique(Par2D{1}.t);
fid=fopen(Particle3DFile,'w');       
fwrite(fid,length(Frames),'int32'); % header is integer frame count
for Frame=Frames(1):Frames(2)-Frames(1):Frames(end)
    disp(['Processing Frame:...',num2str(Frame)]);
    for i=1:nCam
        id_p{i}=find(Par2D{i}.t==Frame); %%% particle index on camera i
        disp(['......',num2str(i),'... camera has','...particles...',...
            num2str(length(id_p{i}))]);
    end
    P_cur=[]; %%% initialize the particle 3D info for current frame
    dis_cur=[]; %%% corresponding ray-interestion distance
    MchPix_cur=[]; 
    Flag(1:length(Par2D{3}.t))=0; %%% initial the flag for particles on camera 3
                                 %%% =0 is un-used; =1 is used
    %% search all particles in camera 1, and find a best match on 2,3,4
    PrimCam=1;
    MatchCam=[2 3 4];
    for i=1:length(id_p{PrimCam})
        %%%% generate the 3D ray passing through particle i
        u=Par2D{PrimCam}.x(id_p{PrimCam}(i));
        v=Par2D{PrimCam}.y(id_p{PrimCam}(i));
        [ray_p1,ray_p2]=dlt_image2ray(coefs(:,PrimCam),[u v]);        
        %%%% find the possible matches on other cameras
        for j=2:nCam % num of cameras
            %%%% from world to second camera 
            proj1=dlt_world2image(coefs(:,MatchCam(j-1)), ray_p1);
            proj2=dlt_world2image(coefs(:,MatchCam(j-1)), ray_p2);

            et = (proj2-proj1);            
            et = et/sqrt(et(1).^2+et(2).^2); %%% unit vector along epi-line    
            en = [-et(2) et(1)]; % normal unit vector
    
            del = [Par2D{MatchCam(j-1)}.x(id_p{MatchCam(j-1)}) ...
                Par2D{MatchCam(j-1)}.y(id_p{MatchCam(j-1)})]-proj1;            
            dist = abs(sum(del.*en,2)); % distance of point j to projected line i,
                                        % distance in pixels
            matches = dist<mindist_2D; % match markers                      
            id_pMc{MatchCam(j-1)}=id_p{MatchCam(j-1)}(find(matches));
        end
        %%%% connect all possible matches: total number of matches =
        %%%% id_pMc{2}*id_pMc{3}*id_pMc{4}....
        cam2d=[];
        id_pMcCam3=[];
        for j=1:length(id_pMc{MatchCam(1)})
            for k=1:length(id_pMc{MatchCam(2)})
                for n=1:length(id_pMc{MatchCam(3)})
                    id_pMcCam3=[id_pMcCam3;id_pMc{MatchCam(2)}(k)];
                    cam2d_temp=[u v...
                        Par2D{2}.x(id_pMc{MatchCam(1)}(j)) Par2D{2}.y(id_pMc{MatchCam(1)}(j))...
                        Par2D{3}.x(id_pMc{MatchCam(2)}(k)) Par2D{3}.y(id_pMc{MatchCam(2)}(k))...
                        Par2D{4}.x(id_pMc{MatchCam(3)}(n)) Par2D{4}.y(id_pMc{MatchCam(3)}(n))];
                    cam2d=[cam2d;cam2d_temp];
                end
            end
        end
        if isempty(cam2d)
            continue;
        end
        %%%% trianglue: get 3D position and ray-intersection distance for
        %%%% all possible matches 
        [P,dist_3d] = dlt_image2world(coefs,cam2d);
        [dist_3d,I] = sort(dist_3d,1);% sort by intersection distance
        dist_3d=dist_3d(1); % get best one
        P=P(I(1),:); % get best one by minimal ray-intersection distance
        cam2d=cam2d(I(1),:);
        id_pMcCam3=id_pMcCam3(I(1),:); % the particle id used for calculation
        if dist_3d<mindist_3D % good match
            P_cur=[P_cur;P];
            dis_cur=[dis_cur;dist_3d];
            MchPix_cur=[MchPix_cur;cam2d];
            Flag(id_pMcCam3)=1; %%% mark for particle on view 3 that as used
        end
    end
    %% search for camera 3 and particles that haven't been matched
    PrimCam=3;
    MatchCam=[1 2 4];
    for i=1:length(id_p{PrimCam})
        if Flag(id_p{PrimCam}(i))==1 %%% particle has been used 
            continue
        end
        %%%% generate the 3D ray passing through particle i
        u=Par2D{PrimCam}.x(id_p{PrimCam}(i));
        v=Par2D{PrimCam}.y(id_p{PrimCam}(i));
        [ray_p1,ray_p2]=dlt_image2ray(coefs(:,PrimCam),[u v]);        
        %%%% find the possible matches on other cameras
        for j=2:nCam % num of cameras
            %%%% from world to second camera 
            proj1=dlt_world2image(coefs(:,MatchCam(j-1)), ray_p1);
            proj2=dlt_world2image(coefs(:,MatchCam(j-1)), ray_p2);

            et = (proj2-proj1);            
            et = et/sqrt(et(1).^2+et(2).^2); %%% unit vector along epi-line    
            en = [-et(2) et(1)]; % normal unit vector
    
            del = [Par2D{MatchCam(j-1)}.x(id_p{MatchCam(j-1)}) ...
                Par2D{MatchCam(j-1)}.y(id_p{MatchCam(j-1)})]-proj1;            
            dist = abs(sum(del.*en,2)); % distance of point j to projected line i,
                                        % distance in pixels
            matches = dist<mindist_2D; % match markers                      
            id_pMc{MatchCam(j-1)}=id_p{MatchCam(j-1)}(find(matches));
        end
        %%%% connect all possible matches: total number of matches =
        %%%% id_pMc{1}*id_pMc{2}*id_pMc{4}....
        cam2d=[];
        for j=1:length(id_pMc{MatchCam(1)})
            for k=1:length(id_pMc{MatchCam(2)})
                for n=1:length(id_pMc{MatchCam(3)})
                    cam2d_temp=[Par2D{1}.x(id_pMc{MatchCam(1)}(j)) Par2D{1}.y(id_pMc{MatchCam(1)}(j))...
                        Par2D{2}.x(id_pMc{MatchCam(2)}(k)) Par2D{2}.y(id_pMc{MatchCam(2)}(k))...
                        u v...
                        Par2D{4}.x(id_pMc{MatchCam(3)}(n)) Par2D{4}.y(id_pMc{MatchCam(3)}(n))];
                    cam2d=[cam2d;cam2d_temp];
                end
            end
        end
        if isempty(cam2d)
            continue;
        end
        %%%% trianglue: get 3D position and ray-intersection distance for
        %%%% all possible matches 
        [P,dist_3d] = dlt_image2world(coefs,cam2d);
        [dist_3d,I] = sort(dist_3d,1);% sort by intersection distance
        dist_3d=dist_3d(1); % get best one
        P=P(I(1),:); % get best one by minimal ray-intersection distance
        cam2d=cam2d(I(1),:);        
        if dist_3d<mindist_3D % good match
            P_cur=[P_cur;P];
            dis_cur=[dis_cur;dist_3d];
            MchPix_cur=[MchPix_cur;cam2d];            
        end
    end
    %%%%% if two particles are too close to each other, select the best one
    %%%%% based on the smallest in hs_temp; because one of them is ghost
    %%%%% particle
    Flag=[];
    Flag(1:size(P_cur,1))=1;
    for i=1:size(P_cur,1)
        dist=sum((P_cur(i,:)-P_cur)'.^2).^0.5;
        id=find(dist<minSepDist_3D);
        if length(id)>=2 %%% exist two very close particle, one is ghost
            id_ghost=find(dis_cur(id)>min(dis_cur(id)));
            Flag(id(id_ghost))=0; %%% marker the ghost
        end
    end    
    id=find(Flag==1);
    P_cur=P_cur(id,:);
    dis_cur=dis_cur(id);
    MchPix_cur=MchPix_cur(id,:);
    clear Flag
    %%%% save results for current frame
    num_matches=size(P_cur,1);
    fwrite(fid,num_matches,'int32'); % header is integer frame count
    fwrite(fid,P_cur','float32'); % write particle 3D location x1 y1 z1 x2 y2 z2...
    %%%% add time into the particle info
    XYZt=[XYZt;[P_cur repmat(Frame,num_matches,1)]];
% %     Bg_pts=[Bg_pts;MchPix_cur];
    disp(['...... Number of particles reconstructed ...',num2str(num_matches)]);
    disp(['...... Mean 3d-ray distance...',num2str(mean(dis_cur))]);
end
fclose(fid);
save([datafolder,'particle3Dlist.mat'],'XYZt');
% % save([datafolder,'Bg_pts.mat'],'Bg_pts');

end


function [xyz1,xyz2] = dlt_image2ray(c,uv)
% This function reconstructs the 3D ray passing through the points on
% camera using the 11 coefficience 
%
% Inputs:
%  c - 11 DLT coefficients for this cameras, [11,1] array
%  uv - [u,v] pixel coordinates, [n,2] array
%
% Outputs:
%  xyz1,xyz2 - two arbitral point on the 3D ray, [n,3] array
%
% Hangjian Ling, Postdoc, Stanford University, 2017
% http://www.kwon3d.com/theory/dlt/dlt.html

%%%%%%%%%%%%%%%%%%%
% % (a1 a2 a3 .  x .  (a7
% %  a4 a5 a6)*  y =   a8)
% %              z
%%%%%%%%%%%%%%%%%%%%%%%%%%%
np=size(uv,1); % number of points on the camera

a1=uv(:,1)*c(9)-c(1);
a2=uv(:,1)*c(10)-c(2);
a3=uv(:,1)*c(11)-c(3);

a4=uv(:,2)*c(9)-c(5);
a5=uv(:,2)*c(10)-c(6);
a6=uv(:,2)*c(11)-c(7);

a7=c(4)-uv(:,1);
a8=c(8)-uv(:,2);

D=a2.*a4-a1.*a5;

%%%% first points on np rays
xyz1(1:np,3)=-10;
xyz1(:,1)=(a2.*(a8-a6.*xyz1(:,3))-a5.*(a7-a3.*xyz1(:,3)))./D;
xyz1(:,2)=(a4.*(a7-a3.*xyz1(:,3))-a1.*(a8-a6.*xyz1(:,3)))./D;

%%%% second points on np rays
xyz2(1:np,3)=1000;
xyz2(:,1)=(a2.*(a8-a6.*xyz2(:,3))-a5.*(a7-a3.*xyz2(:,3)))./D;
xyz2(:,2)=(a4.*(a7-a3.*xyz2(:,3))-a1.*(a8-a6.*xyz2(:,3)))./D;

end

function [uv] = dlt_world2image(c,xyz)
% This function reconstructs the pixel coordinates of a 3D coordinate as
% seen by the camera specificed by DLT coefficients c
%
% Inputs:
%  c - 11 DLT coefficients for the camera, [11,1] array
%  xyz - [x,y,z] coordinates over f frames,[f,3] array
%
% Outputs:
%  uv - pixel coordinates in each frame, [f,2] array
%
% Hangjian Ling, Postdoc, Stanford University, 2017
% http://www.kwon3d.com/theory/dlt/dlt.html

uv(:,1)=(xyz(:,1).*c(1)+xyz(:,2).*c(2)+xyz(:,3).*c(3)+c(4))./ ...
  (xyz(:,1).*c(9)+xyz(:,2).*c(10)+xyz(:,3).*c(11)+1);
uv(:,2)=(xyz(:,1).*c(5)+xyz(:,2).*c(6)+xyz(:,3).*c(7)+c(8))./ ...
  (xyz(:,1).*c(9)+xyz(:,2).*c(10)+xyz(:,3).*c(11)+1);

end

function [xyz,dist] = dlt_image2world(c,cam2d)
% This function reconstructs the 3D position of a coordinate based on a set
% of DLT coefficients and [u,v] pixel coordinates from 2 or more cameras
%
% Inputs:
%  c - 11 DLT coefficients for all n cameras, [11,n] array
%  camPts - [u,v] pixel coordinates from all n cameras, [np,2] array
%
% Outputs:
%  xyz - the xyz location in each frame, an [f,3] array
%  dist - the mean distance from the recon 3d point to each 3d ray
%
% Hangjian Ling, Stanford, 2017

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Method 1
% principle: minimizing the distance to all rays in a least square sense
% reference: en.wikipedia.org/wiki/Line-line_intersection
% 
I=[1 0 0;0 1 0;0 0 1];
for i=1:size(cam2d,1) %%% process for each matched particles
    for icam=1:size(c,2)
        %%% 3d ray cross the 2D points i on icam
        [ray_p1,ray_p2]=dlt_image2ray(c(:,icam),cam2d(i,2*icam-1:2*icam));
        %%% unit vector along ray for each camera
        u(:,icam)=(ray_p1-ray_p2)'; 
        u(:,icam)=u(:,icam)/sqrt(sum(u(:,icam).^2)); %% 3x1 array   
        %%%% a point on the ray
        pRay(:,icam)=ray_p1';
   
        uM(:,:,icam) = I-u(:,icam)*u(:,icam)'; %% 3x3xicam array
        pM(:,icam)=uM(:,:,icam)*pRay(:,icam); %%% 3xicam array
    end
    spM=sum(pM,2); %%% 3x1 array
    M=sum(uM,3); %%% 3x3 array
    xyz(i,:)=M\spM; %%% npx3 array, the 3D location of n points
    
    %%%%% finally calculate the distance between p and each ray
    for icam = 1:size(c,2)
        temp = xyz(i,:)' - xyz(i,:)*u(:,icam)*u(:,icam) - pM(:,icam);
        h(icam) = sqrt(sum(temp.^2));
    end
    %%% find the mean distance (same positive, same negative)
    dist(i) = sqrt(mean(h.^2));
end
dist=dist';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Method 2
%%%% principle: least square method, Ax=B, solve the x using A\B
% % % cdx=1:size(c,2);
% % % for i=1:size(cam2d,1)    
% % %     % preallocate least-square solution matrices
% % %     m1=zeros(size(c,2)*2,3);
% % %     m2=zeros(size(c,2)*2,1);
% % %     
% % %     m1(1:2:size(c,2)*2,1)=cam2d(i,cdx*2-1).*c(9,cdx)-c(1,cdx);
% % %     m1(1:2:size(c,2)*2,2)=cam2d(i,cdx*2-1).*c(10,cdx)-c(2,cdx);
% % %     m1(1:2:size(c,2)*2,3)=cam2d(i,cdx*2-1).*c(11,cdx)-c(3,cdx);
% % %     m1(2:2:size(c,2)*2,1)=cam2d(i,cdx*2).*c(9,cdx)-c(5,cdx);
% % %     m1(2:2:size(c,2)*2,2)=cam2d(i,cdx*2).*c(10,cdx)-c(6,cdx);
% % %     m1(2:2:size(c,2)*2,3)=cam2d(i,cdx*2).*c(11,cdx)-c(7,cdx);
% % %     
% % %     m2(1:2:size(c,2)*2,1)=c(4,cdx)-cam2d(i,cdx*2-1);
% % %     m2(2:2:size(c,2)*2,1)=c(8,cdx)-cam2d(i,cdx*2);
% % %     
% % %     % get the least squares solution to the reconstruction
% % %     xyz(i,1:3)=mldivide(m1,m2);
% % %     if nargout>1
% % %       % compute ideal [u,v] for each camera
% % %       uv=m1*xyz(i,1:3)';
% % %       
% % %       % compute the number of degrees of freedom in the reconstruction
% % %       dof=numel(m2)-3;
% % %       
% % %       % estimate the root mean square reconstruction error
% % %       dist(i,1)=(sum((m2-uv).^2)/dof)^0.5;
% % %     end
% % % end
%%%%%%%%%%%%%%%%%%% Results are very similar to the first method

end