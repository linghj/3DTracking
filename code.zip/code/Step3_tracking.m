function Step3_tracking(datafolder,nCam,framerange,frameRate,max_u)
% Step3_tracking: Track individual's motion in 3D space using the C++ executable codes 
% (a) 'TrackCcode -> trackParticles'
% (b) 'TrackCcode -> difftracks'
%
% Before running this code, please go to the folder 'TrackCcode', and compile
% the C++ codes. To compile the code in Mac OS, one could:
% Open terminal -> cd: /code/TrackCcode/lib/ -> make all
% Open terminal -> cd: /code/TrackCcode/ -> make all
%
% Algorithm: 
%      predict the particle location on next frame based on velocity and
%      acceleration (three-frame predict method)
%      1. velocity and acceleration is calculated by convoluting the position
%      to a Guassian smoothing and differenting kernels
%      2. able to deal with particle temporal disappearance
%      3. for more information refer to:
%       'Ouellette, et al., (2006). A quantitative study of three-dimensional 
%        Lagrangian particle tracking algorithms. Experiments in Fluids 40, 301-313'
%     
% Input parameters
%     datafolder - the name of folder containing particles 3D positions (generated from step 2)
%     nCam       - the number of cameras
%     framerange - the range of images need to be processed, eg. [1 50]
%                  same as the one used in Step 1
%     frameRate  - the frame rate used to capture the images
%     max_u      - the maximal allowed velocity of birds
%
% Output files:
%     tracks.mat: a nx11 matrix where 
%                 Column 1:    birdID; 
%                 Columns 2-4: x y z; (position in three dimensions)
%                 Column 5:    t; (time)
%                 Columns 6-8: u v w; (velocity in three dimensions)
%                 Columns 9-11: au av aw; (acceleration in three dimensions)
%     results are stored at the same folder where the data are stored
%
% Example: 
%    Step3_tracking('Data_raw/',4,[1 50],40,30);
%
% Other m-files required: read_gdf.m
% Subfunctions: track code in the folder 'TrackCcode'
% MAT-files required: none
%
% Author: Hangjian Ling, Postdoc, Stanford University
% email address: linghj@stanford.edu 
%
% May 2018; Last revision: May-14-2018

%%%% the list of particle in 3D space (obtained from step 2)
Particle3DFile = [datafolder,'particle3Dlist.dat'];

%%%% output file name
TracksFile = [datafolder,'tracks.gdf'];
TracksFinalFile = [datafolder 'retracks.gdf'];

%%%%%% default tracking parameters
backup = [datafolder,'']; %%% calib results 
backup2 = [datafolder,''];
ccodefolder = 'TrackCcode/';
trackconfig = [ccodefolder,'trackingconfig.txt'];
top = 0.1;       % top percentile of intensities to keep 
low_cutoff = 1;   % low cutoff (in pixels) for bandpass filter
high_cutoff = 5;  % high cutoff (in pixels) for bandpass filter
radius_match= 3;  % radius (in pixels) within which we only allow a single particle
npredict=2;
max_disp=max_u*1/frameRate; %%% 0.5/ m ~ m/s
memory_frame=2;

%%%% make tracking configuration file
fid = fopen(trackconfig,'wt');
fprintf(fid, [num2str(nCam) ' # numbers of cameras \n']);
fprintf(fid,[backup2 ' # backup line \n']);
fprintf(fid,[Particle3DFile ' # data for tracking \n']);
fprintf(fid, '/Users/      # 3 cameras\n');
fprintf(fid, '/Users/      # 4 cameras\n'); %%%% add this line if have 4 cameras
fprintf(fid,[backup ' # backup line -2 \n']);
fprintf(fid,[num2str(frameRate) ' # frame rate (in frames per second) \n']);
fprintf(fid,[num2str(top) ' # top percentile of intensities to keep \n']);
fprintf(fid,[num2str(low_cutoff) ' # low cutoff (in pixels) for bandpass filter \n']);
fprintf(fid,[num2str(high_cutoff) ' # high cutoff (in pixels) for bandpass filter \n']);
fprintf(fid,[num2str(radius_match) ' # radius (in pixels) within which we only allow a single particle \n']);
fprintf(fid,[num2str(npredict) ' # npredict (number of future frames to consider) \n']);
fprintf(fid,[num2str(max_disp) ' # max_disp (maximum allowed displacement of a particle from its estimated position) \n']);
fprintf(fid,[num2str(memory_frame) ' # memory (number of frames a particle can disappear before we end the track) \n']);
fprintf(fid,[num2str(framerange(1)) ' # first frame to process \n']);
fprintf(fid,[num2str(framerange(2)) ' # last frame to process \n']);
fprintf(fid,[num2str(TracksFile) ' # output trackfile name \n']);
fclose(fid);

%%%%% calling trackParticles in c++
system([ ccodefolder 'trackParticles ' trackconfig ' ' Particle3DFile])
maxTrackLength=4;
smoothening=3;
system([ ccodefolder 'difftracks ' TracksFile ' ' num2str(maxTrackLength)...
    ' ' num2str(smoothening) ' ' TracksFinalFile])

Dt=1/frameRate;
tracks = read_gdf(TracksFinalFile); %%% d1-ind;2-4 xyz;5-t;6-8 uvw;9-11 a 
tracks(:,6:8)=tracks(:,6:8)/Dt; %% get U
tracks(:,9:11)=tracks(:,9:11)/Dt^2; %% get A

%%%% save tracking result into .mat file
save([datafolder,'tracks.mat'],'tracks');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% END of Processing

%% Optional: plot all trajectories in 3D 
NumT=max(tracks(:,1))+1;
for j=1:NumT
    C{j}.color=rand(1,3); % color    
end
figure('units','inches','position',[1 1 6 5]);    
for i=1:NumT
    id=find(tracks(:,1)==i-1);
    XYZ=tracks(id,2:4);  
    plot3(XYZ(:,1),XYZ(:,2),XYZ(:,3),...
        '-','Color',C{i}.color,'LineWidth',2);hold on    
    scatter3(XYZ(end,1),XYZ(end,2),XYZ(end,3),20,C{i}.color,'o','filled'); 
    text(XYZ(end,1)+2,XYZ(end,2),XYZ(end,3),num2str(i),'fontsize',10);    
end
view([45,20]);grid on;box on;axis equal;
set(gca,'FontUnits','points','FontWeight','normal',...
    'Units','normalized','FontSize',14,'FontName','Times');  


end
