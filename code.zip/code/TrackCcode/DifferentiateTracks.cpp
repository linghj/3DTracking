/*
 *  DifferentiateTracks.cpp
 *
 *  Created by Nicholas Ouellette on 8/1/08.
 *
 */

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <cmath>
#include <deque>

#include <Trackfile.h>

using namespace std;

// calculate the value of the velocity kernel
double VKernel(double t);
// compute the constants for the acceleration kernel
void CalcConst();
// calculate the value of the acceleration kernel
double AKernel(double t);
// convolve the positions with the kernel
double Convolve(double vals[], double kvals[]);

// global variables

// kernel constants
double Av;
double Aa;
double Ba;
// kernel width
double w;
// number of points for the fit
int L;
// as a convenience, L cast as a double
double Ld;

int main(int argc, char** argv)
{
  if (argc < 4) {
    cerr << "Usage: " << argv[0] << " <trackfile name> <fit half-length> <filter half-width> [<output file name>]" << endl;
    exit(1);
  }
  
  // some definitions  
  string filename = string(argv[1]);
  L = atoi(argv[2]);
  Ld = static_cast<double>(L);
  w = atof(argv[3]);
	
  // calculate Av
  double erflw = erf(Ld / w);
  double rootpi = sqrt(M_PI);
  Av = 1.0 / (0.5 * w * w * (rootpi * w * erflw - 2.0 * Ld * exp(-Ld * Ld / (w * w))));
  
  // calculate Aa and Ba
  CalcConst();
  
  //ofstream tmp("kernel.dat", ios::out);
  
  // compute the needed kernel values
  double Vkvals[(2 * L) + 1];
  double Akvals[(2 * L) + 1];
  for (int i = 0; i < (2 * L) + 1; ++i) {
    double t = -L + i;
		Vkvals[i] = VKernel(t);
		Akvals[i] = AKernel(t);
		
		//tmp << t << "\t" << VKernel(t) << "\t" << AKernel(t) << "\n";
  }
  //tmp.close();
  
  
  // open an output file
  ofstream out;
  if (argc == 5) {
    out.open(argv[4], ios::out | ios::binary);
  } else {
    out.open("tv.gdf", ios::out | ios::binary);
  }
  
  // write a mock header (since we don't yet know the number of points)
  int magic = 82991;
  out.write(reinterpret_cast<const char*>(&magic), 4);
  int tmpi = 2;
  out.write(reinterpret_cast<const char*>(&tmpi), 4);
  tmpi = 11;
  out.write(reinterpret_cast<const char*>(&tmpi), 4);
  tmpi = 0;
  out.write(reinterpret_cast<const char*>(&tmpi), 4);
  tmpi = 4;
  out.write(reinterpret_cast<const char*>(&tmpi), 4);
  tmpi = 0;
  out.write(reinterpret_cast<const char*>(&tmpi), 4);
  
  // how many data points will be going into the trackfile?
  int ndatapoints = 0;
  
  // read in the trackfile
  Trackfile tracks(filename);
  // compute the number of trajectories
  tracks.NumTracks();
  
  // now loop over the trajectories
  for (int i = 0; i < tracks.NumTracks(); ++i) {
    // read a trajectory
    deque<float> x;
		deque<float> y;
		deque<float> z;
		deque<float> t;
		deque<float> fake;
		tracks.GetNextTrack(&x, &y, &z, &t, &fake);
		
		// is this track too short?
		int tracklength = x.size();
		if (tracklength < (2 * L) + 1) {
			// yes: we have to skip it
			continue;
		}
		
		// loop over the track with a sliding window of width 2L + 1
		double valsx[(2 * L) + 1];
		double valsy[(2 * L) + 1];
		double valsz[(2 * L) + 1];
		for (int j = L; j < tracklength - L - 1; ++j) {
			for (int s = 0; s < (2 * L) + 1; ++s) {
				valsx[s] = x[j - L + s];
				valsy[s] = y[j - L + s];
				valsz[s] = z[j - L + s];
			}
			
			float val = static_cast<float>(i);
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = x[j];
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = y[j];
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = z[j];
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = t[j];
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = Convolve(valsx, Vkvals);
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = Convolve(valsy, Vkvals);
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = Convolve(valsz, Vkvals);
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = Convolve(valsx, Akvals);
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = Convolve(valsy, Akvals);
			out.write(reinterpret_cast<const char*>(&val), 4);
			val = Convolve(valsz, Akvals);
			out.write(reinterpret_cast<const char*>(&val), 4);
			
			++ndatapoints;
		}
		
		if (i % 10000 == 0) {
			cout << "Processed " << i << " of " << tracks.NumTracks() << " tracks." << endl;
		}
  }
  
  // now fix the header
  out.seekp(12, ios::beg);
  out.write(reinterpret_cast<const char*>(&ndatapoints), 4);
  tmpi = ndatapoints * 11;
  out.seekp(4, ios::cur);
  out.write(reinterpret_cast<const char*>(&tmpi), 4);
  
  out.close();
  
  return 0;
}

void CalcConst()
{
  double sumA = 0;
  double sumB = 0;
  
  for (int i = 1; i < 2 * L; ++i) {
    double t = -L + i;
    
    double tmpA = ((0.5 * t * t) - (Ld * Ld / 6.0)) * ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w));
    
    double tmpB = ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w));
    
    if (i % 2 == 1) {
      sumA += tmpA * 4.0;
      sumB += tmpB * 4.0;
    } else {
      sumA += tmpA * 2.0;
      sumB += tmpB * 2.0;
    }
  }
  
  double t = -L;
  sumA += ((0.5 * t * t) - (Ld * Ld / 6.0)) * ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w));
  sumB += ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w));
  
  t = L;
  sumA += ((0.5 * t * t) - (Ld * Ld / 6.0)) * ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w));
  sumB += ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w));
  
  sumA /= 3.0;
  sumB /= 3.0;
  
  Aa = 1.0 / sumA;
  Ba = (-1.0 / (2.0 * Ld)) * Aa * sumB;
}

double VKernel(double t)
{
  return (Av * t * exp(-t * t / (w * w)));
}

double AKernel(double t)
{
  return ((Aa * ((2.0 * t * t / (w * w)) - 1.0) * exp(-(t * t) / (w * w))) + Ba);
}

// convolve using Simpson's rule
double Convolve(double vals[], double kvals[])
{
  double sum = 0;
	
  for (int i = 1; i < 2 * L; ++i) {
    if (i % 2 == 1) {
      sum += vals[i] * kvals[i] * 4.0;
    } else {
      sum += vals[i] * kvals[i] * 2.0;
    }
  }
  sum += vals[0] * kvals[0];
  sum += vals[2 * L] * kvals[2 * L];
  sum /= 3.0;
	
  return sum;
}
