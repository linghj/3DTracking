/*
 *  Position.h
 *
 *  A Position object holds the coordinates of a single particle, and 
 *  has lots of useful operators defined.
 *
 *  Last update: 10/28/11 by NTO (made 3D)
 *
 */

#ifndef POSITION_H
#define POSITION_H

#include <iostream>
#include <fstream>
#include <cmath>

class Position {
public:
  // constructor: does nothing
  Position() {};
  // constructor: initializes the coordinates
  Position(double NewX, double NewY, double NewZ);
  // copy-constructor
  Position(const Position& p);
  // destructor: nothing to do
  ~Position() {};
  
  // set this position to be fake, i.e., an estimated position
  void SetFake();
  // check if this position is fake
  bool IsFake() const;

  // get x component
  double X() const;
  // get y component
  double Y() const;
	// get z component
	double Z() const;
  
  // get the squared Euclidean distance between two Positions
  // (don't take the square root for efficiency)
  friend double Distance(const Position& p1, const Position& p2);
  // get the magnitude of the vector
  double Magnitude() const;
	// get the squared magnitude
	double Magnitude2() const;

	// scalar product
  friend double Dot(const Position& left, const Position& right);
	// element-wise multiplication
	friend const Position Multiply(const Position& left, const Position& right);
	
  // member operators
  Position& operator=(const Position& p);
  // vector sum and difference
  Position& operator+=(const Position& right);
  Position& operator-=(const Position& right);
  // scalar multiplication and division
  Position& operator*=(double right);
  Position& operator/=(double right);
	// element by element multiplication
	Position& operator*=(const Position& right);

  // non-member operators

  // comparison
  friend int operator==(const Position& left, const Position& right);
  friend int operator!=(const Position& left, const Position& right);
	// compare y values (for sorting)
	friend int operator<(const Position& left, const Position& right);
	friend int operator>(const Position& left, const Position& right);
  // vector sum and difference
  friend const Position operator+(const Position& left, const Position& right);
  friend const Position operator-(const Position& left, const Position& right);
  // scalar multiplication and division
  friend const Position operator*(const Position& left, double right);
  friend const Position operator*(double left, const Position& right);
  friend const Position operator/(const Position& left, double right);
  // printing
  friend std::ostream& operator<<(std::ostream& os, const Position& p);

	
	
private:
  double x;
  double y;
	double z;
  // a flag specifying whether this position is real or estimated
  bool fake;    
};

//  Inline Function Definitions

inline Position::Position(double NewX, double NewY, double NewZ) 
: x(NewX), y(NewY), z(NewZ), fake(false)
{}

inline Position::Position(const Position& p) 
: x(p.x), y(p.y), z(p.z), fake(p.fake)
{}

inline void Position::SetFake()
{
  fake = true;
}

inline bool Position::IsFake() const
{
  return fake;
}

inline double Position::Magnitude() const
{
  return sqrt(x * x + y * y + z * z);
}

inline double Position::Magnitude2() const
{
  return (x * x + y * y + z * z);
}

inline double Position::X() const
{
	return x;
}

inline double Position::Y() const
{
	return y;
}

inline double Position::Z() const
{
	return z;
}

inline Position& Position::operator=(const Position& p)
{
  x = p.x;
  y = p.y;
	z = p.z;
  fake = p.fake;

  return *this;
}

inline Position& Position::operator+=(const Position& right)
{
  x += right.x;
  y += right.y;
	z += right.z;

  return *this;
}

inline Position& Position::operator-=(const Position& right)
{
  x -= right.x;
  y -= right.y;
	z -= right.z;

  return *this;
}

inline Position& Position::operator*=(double right)
{
  x *= right;
  y *= right;
	z *= right;

  return *this;
}

inline Position& Position::operator/=(double right)
{
  x /= right;
  y /= right;
	z /= right;

  return *this;
}

inline Position& Position::operator*=(const Position& right)
{
	x *= right.x;
	y *= right.y;
	z *= right.z;
	
	return *this;
}


#endif // POSITION_H
