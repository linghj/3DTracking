/*
 * Track particles that have already been stereomatched.
 *
 * Based on MPIDS/Cornell tracking code, but *heavily modified*
 *
 * Written 3/8/12 by NTO
 */

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <deque>
#include <vector>

#include <Position.h>
#include <Frame.h>
#include <Tracker.h>

using namespace std;

// configuration parameters
struct ConfigFile {
  int ncams;
  deque<string> movienames;
  string setupfile;
	double fps;
  double prctile;
  double lopass;
  int hipass;
  double cluster_rad;
  int npredict;
  double max_disp;
  int memory;
  int first;
  int last;
  string outname;
};


void ImportConfiguration(struct ConfigFile* config, char* name);

int main(int argc, char** argv) 
{
  if (argc < 3) {
    cerr << "Usage: " << argv[0] << " <configuration file> <3D position file>" << endl;
    exit(1);
  }
  
	struct ConfigFile config;
	ImportConfiguration(&config, argv[1]);
	

	// are we trying to track with too much future information?
  if (config.npredict > 2) {
    cerr << "Error: too many predicted frames requested!" << endl;
    exit(1);
  }

	vector<Frame> frames;
	
	// read the positions
	ifstream in(argv[2], ios::in | ios::binary);
	int nframes;
	in.read(reinterpret_cast<char*>(&nframes), 4);
	for (int i = 0; i < nframes; ++i) {
		int npos;
		in.read(reinterpret_cast<char*>(&npos), 4);
		deque<Position> pos;
		for (int j = 0; j < npos; ++j) {
			float x, y, z;
			in.read(reinterpret_cast<char*>(&x), 4);
			in.read(reinterpret_cast<char*>(&y), 4);
			in.read(reinterpret_cast<char*>(&z), 4);
			pos.push_back(Position(x,y,z));
		}
		frames.push_back(Frame(pos));
	}
	in.close();
	
	// finally, do the tracking
  cout << "Tracking..." << endl;
  Tracker::TrackMode mode = Tracker::FRAME3;
  if (config.npredict == 0) {
    mode = Tracker::FRAME2;
  } else if (config.npredict == 1) {
    mode = Tracker::FRAME3;
  } else if (config.npredict == 2) {
    mode = Tracker::FRAME4;
  }
  Tracker t(mode, config.max_disp, config.memory, config.fps, 
            config.outname);
  t.MakeTracks(frames);
  	
  // Done!
  cout << "Done." << endl;
  
  return 0;
}

void ImportConfiguration(struct ConfigFile* config, char* name)
{
  cout << "Reading configuration file..." << endl;
  ifstream file(name, ios::in);
  string line;
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->ncams = atoi(line.c_str());
  
  for (int i = 0; i < config->ncams; ++i) {
    getline(file, line);
    line.erase(line.find_first_of(' '));
    //config->movienames[i] = line;
		config->movienames.push_back(line);
  }
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->setupfile = line;
	
	getline(file, line);
	line.erase(line.find_first_of(' '));
	config->fps = atof(line.c_str());
	
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->prctile = atof(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->lopass = atof(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->hipass = atoi(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->cluster_rad = atof(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->npredict = atoi(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->max_disp = atof(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->memory = atoi(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->first = atoi(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->last = atoi(line.c_str());
  
  getline(file, line);
  line.erase(line.find_first_of(' '));
  config->outname = line;
}
