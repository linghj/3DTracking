function Step1_BirdDetection(nCam,datafolder,framerange,thresh,arealim)
% Step1_BirdDetection: detect the 2D locations of birds from 2D images
%
% Image requirments: birds are represented by dark pixels with relatively low 
% intensity values on a white background, image formate '.tif' or '.tiff';
% image background is relatively uniform (otherwise the background need to be subtracted)  
% Each folder represents one camera and contains a serie of images 
%
% Inputs:
%    nCam       - number of cameras
%    datafolder - the name of folder containing raw data
%    framerange - the range of images to be processed, eg. [1 50]
%    thresh     - pixels with value larger than 'thresh' is selected as pixel
%                 that belong to bird
%                    eg. [0.1 0.15 0.1 0.2] for four cameras
%                    eg. [0.1 0.1 0.1] for three cameras
%                 Reduce the threshold value slightly if not all birds are detected
%    arealim    - the treshold of bird size, eg. [1.2 20], only select bird
%                 with size in the range of 1.2 to 20 pixels
%
% Outputs:
%    2D locations of birds saved as one file for each camera
%    results are stored at the same folder where the data are stored
%    The output files will be used to reconstruct the 3D positions of bird
%
% Example: 
%    Step1_BirdDetection(4,'Data_raw/',[1 50],[0.1 0.1 0.1 0.1],[1.2 20]);
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Hangjian Ling, Postdoc, Stanford University
%         Nicholas Ouellette, Stanford University
% email address: linghj@stanford.edu; nto@stanford.edu
%
% May 2018; Last revision: May-14-2018

%%%% folder name that contains image data
datafolder_cam{1} = [datafolder,'camera1/']; 
datafolder_cam{2} = [datafolder,'camera2/'];
datafolder_cam{3} = [datafolder,'camera3/'];
datafolder_cam{4} = [datafolder,'camera4/'];
%%%% output file name that contains list of particle 2D positions
Particle2DFile{1} = [datafolder,'particle2Dlist_1.mat'];
Particle2DFile{2} = [datafolder,'particle2Dlist_2.mat'];
Particle2DFile{3} = [datafolder,'particle2Dlist_3.mat'];
Particle2DFile{4} = [datafolder,'particle2Dlist_4.mat'];

for i=1:nCam
    Img_segment(datafolder_cam{i},framerange,...
        Particle2DFile{i},thresh(i),arealim);        
end

end


function Img_segment(filepath,framerange,outname,threshold,arealim)
%%%%% Perform image segmentation and find 2d location of particles
ImgSer=dir([filepath,'*.tiff']);
if isempty(ImgSer)
    ImgSer=dir([filepath,'*.tif']);
end
%%%% save birds 2D locations into x,y, and the corresponding frame number t
x=[];y=[];t=[]; 
for ii=framerange(1):framerange(2)
    %%% invert the image such that bird are represent as white pixels with
    %%% high intensity velaues
    I = 1-im2double(imread([filepath,ImgSer(ii).name])); 
    
    %%%% apply low pass filter
    I = imgaussfilt(I,0.5,'FilterSize',5);
    I = I-mean(I);
    
    %%% find the birds
    pos = Get2Dpos(I,arealim,threshold);           
    
    disp(['Number of birds found in ...',...
        num2str(ii),'...is...',num2str(size(pos,1))])
    N=size(pos,1);
    if N>=1
        %%%% remove points on the boundary
        x=[x;pos(:,1)];
        y=[y;pos(:,2)];
        t=[t;repmat(ii,N,1)];
    end
end 
save(outname,'x','y','t');

end

function pos = Get2Dpos(I,arealim,threshold)
    BW=im2bw(I,threshold);
    
    %%%% reduce the particle area, so overlap particle will be separated
    PtAreaThr=0.8;
    props=regionprops(BW,I,'MaxIntensity','PixelValues','PixelIdxList');     
    MaxInt=vertcat(props.MaxIntensity);
    for i=1:length(MaxInt)
        IntThreh=MaxInt(i)*PtAreaThr; %%% local thresh of particle size
        TempPixelValues=props(i).PixelValues;
        %%%% remove those pixel whose intensity is smaller than Thr*max(Ip)
        Id=find(TempPixelValues<IntThreh);
        BadPixID=props(i).PixelIdxList(Id);
        BW(BadPixID)=0;
    end

    %%%% get region properties from the bw image
    props=regionprops(BW,'Centroid','EquivDiameter');
    %%%%% get center and diameter of each detected 2D blob
    pos=vertcat(props.Centroid);
    D=vertcat(props.EquivDiameter);
    %%%% remove particle on the boundary of images
    if isempty(pos)
        return;
    end
    id=find(pos(:,1)>5 & pos(:,2)>5 & ...
        pos(:,1)<size(I,2)-5 & pos(:,2)<size(I,1)-5 & ...
        D>arealim(1) & D<arealim(2));
    pos=pos(id,:);
    D=D(id);
end 