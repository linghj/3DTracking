function Step4_wing(datafolder)
% Step 4. calculate the wingbeat frequency along 3D trajectories 
%
% Aglorithem: obtaine body motion by setting a cut-off frequency in 
% acceleration, and integrate back to get the velocity and position; 
% wing motion is then obtained by subtract the body motion from the
% measured trajectory; wingbeat frequency is obtained by apply a contineous 
% wavelet transfer to the wing motion
%
% Input parameters
%     datafolder - the name of folder contain the tracking results (from Step 3)
%
% Output files:
%     tracks_filt.mat: a nx12 matrix where 
%                 Column 1:    birdID; 
%                 Columns 2-4: x y z; (position in three dimensions)
%                 Column 5:    t; (time)
%                 Columns 6-8: u v w; (velocity in three dimensions)
%                 Columns 9-11: au av aw; (acceleration in three dimensions)
%                 Column 12:   wingbeat frequency (obtained by wavelet transfer)
%     results are stored at the same folder where the data are stored
%
% Example: 
%    Step4_wing('Data_raw/');
%
% Other m-files required: wavelet.m; wave_bases.m;
% Subfunctions: CutFreq
% MAT-files required: 'tracks.mat' track results obtained from step 3
%
% Author: Hangjian Ling, Postdoc, Stanford University
% email address: linghj@stanford.edu 
% May 2018; Last revision: May-14-2018

%%%% load the tracking results:
load([datafolder,'tracks.mat']);

Dt=tracks(2,5)-tracks(1,5); %% time step
NumT=max(tracks(:,1))+1; %% number of total birds found 
%%%% remove track that are too short in length
tracks(:,12)=-1000;
NumT_new=0;
for j=1:NumT
    id=find(tracks(:,1)==j-1);
    if length(id)>10                
        tracks(id,12)=NumT_new;
        NumT_new=NumT_new+1;        
    end
end
id=find(tracks(:,12)~=-1000);
tracks=tracks(id,:);
tracks(:,1)=tracks(:,12);
tracks(:,12)=[];
NumT=NumT_new;
disp(['Total number of tracker after remove are:',num2str(NumT)]);
disp(['Mean traker length:',num2str(size(tracks,1)/NumT)]);

%%% do the filter and calculation of wing motion for each trajectory
CutoffHz=2; %%% cut off frequency at 2 Hz in acceleration
tracks_filt=tracks;
for j=1:NumT
    id=find(tracks(:,1)==j-1);
    
    t=tracks(id,5);
    xyz_old=tracks(id,2:4);
    uvw_old=tracks(id,6:8);
    axyz_old=tracks(id,9:11);
    
    %%%%%%%%%%% filter in fft(a)
    xyz=xyz_old;
    uvw=uvw_old;
    axyz=axyz_old;
    axyz(:,1)=CutFreq(axyz_old(:,1),t,CutoffHz);   
    axyz(:,2)=CutFreq(axyz_old(:,2),t,CutoffHz);   
    [axyz(:,3),f3,P3]=CutFreq(axyz_old(:,3),t,CutoffHz);   

    %%%% intergate az to get the uvw and xyz
    for i=3:size(xyz,1)
        uvw(i,:)=uvw(i-1,:)+Dt*axyz(i-1,:);
        xyz(i,:)=2*xyz(i-1,:)-xyz(i-2,:)+Dt^2*axyz(i-1,:);
    end
    %%%% get the constants rised due to integration
    for i=1:3 % for each direction
        %%%%% find c1*t+c2 by fitting a linear curve to the difference
        diff=xyz(:,i)-xyz_old(:,i);    
        p=polyfit(t,diff,1);
        diff_fit=polyval(p,t);
        xyz(:,i)=xyz(:,i)-diff_fit;
        %%%%% find c1 by fitting a linear curve to the difference
        diff=uvw(:,i)-uvw_old(:,i);    
        diff_fit=mean(diff);
        uvw(:,i)=uvw(:,i)-diff_fit;
    end
    tracks_filt(id,2:4)=xyz;
    tracks_filt(id,6:8)=uvw;
    tracks_filt(id,9:11)=axyz; 
    
    %%%%% Calculate the wingbeat frequency by wavelet transfer
    pad = 1;      % pad the time series with zeroes (recommended)
    dj = 0.01;    % this will do 4 sub-octaves per octave
    s0 = 2*Dt;    % this says start at a scale of 6 months
    j1 = 7/dj;    % this says do 7 powers-of-two with dj sub-octaves each
    mother = 'Morlet';
    %%%%%%%% Wavelet transform: get time-dependent flap freq
    wave_input=axyz_old(:,3); %%% accelation in z before filter, flap phase
    [wave,period,scale,coi] = wavelet(wave_input,Dt,pad,dj,s0,j1,mother);
    power = (abs(wave)).^2 ;        % compute wavelet power spectrum
    [idx,idy]=find(power==max(power));
    Freq=1./period(1,idx)';  % the time-dependent frequency
    %%%% get wingbeat frequency for current time
    tracks_filt(id,12)=Freq;  
end
save([datafolder,'track_filt.mat'],'tracks_filt');

%%% output the tracking results into a plain text file
OutFile=[datafolder,'track_filt.txt'];
fileID = fopen(OutFile,'w');
fprintf(fileID,'%2s %6s %8s %10s %6s %6s %6s %6s %6s %6s %6s %6s\n',...
    'ID','x,m','y,m','z,m','t,s','u,m/s','v,m/s','w,m/s',...
    'ax,m/s2','ay,m/s2','az,m/s2','f_wb,Hz');
fprintf(fileID,'%d %.2f %.2f %.2f %.4f %.2f %.2f %.2f %.4f %.4f %.4f %.4f\n',tracks_filt');
fclose(fileID);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% END of Processing

%% Optional: plot all trajectories in 3D
for j=1:NumT
    C{j}.color=rand(1,3); % color    
end
figure('units','inches','position',[1 1 6 5]);    
for i=1:NumT
    id=find(tracks_filt(:,1)==i-1);
    XYZ=tracks_filt(id,2:4);  
    T=tracks_filt(id,5);    
    plot3(XYZ(:,1),XYZ(:,2),XYZ(:,3),...
        '-','Color',C{i}.color,'LineWidth',2);hold on    
    scatter3(XYZ(end,1),XYZ(end,2),XYZ(end,3),20,C{i}.color,'o','filled'); 
    text(XYZ(end,1)+2,XYZ(end,2),XYZ(end,3),num2str(i),'fontsize',10);    
end
view([45,20]);axis equal;
grid on;box on;
set(gca,'FontUnits','points','FontWeight','normal',...
    'Units','normalized','FontSize',14,'FontName','Times');  

end

function [x_filt,f,P]=CutFreq(x,t,MaxF)
%%%% function to filter the signal in the frequency domain, filter the
%%%% signal with frequency larger than MaxF

    %%%% do fft to find the frequency 
    Fs=1/(t(2)-t(1)); % sampling freq
    L=length(t); % length of signal
    f=Fs*(0:(L/2))/L; % create freqs vector
    y = fft(x);
    ny=length(y); 
    
    %%%% cutoff the frequency and get filtered Y 
    y2=zeros(1,ny);
    ind1=find(f<=MaxF);
    y2(ind1) = y(ind1); % insert required elements
    % create a conjugate symmetric vector of amplitudes
    for k=length(f)+1:ny
        y2(k) = conj(y2(mod(ny-k+1,ny)+1)); % formula from the help of ifft
    end   
    
    %%%% inverse transform
    x_filt=ifft(y2);
    
    %%%% get power-spectrum    
    if rem(L,2)==0
        P = abs(y(1:L/2+1)/L);
    elseif rem(L,2)==1
        P = abs(y(1:(L+1)/2)/L);
    end        
    P(2:end-1) = 2*P(2:end-1);

%     %%%%% plot power-specturm f-P1
%     figure('units','inches','position',[2 1 5 2]);
%     plot(f,log(P),'k-','LineWidth',1); hold on
%     plot([MaxF MaxF],[min(log(P)) max(log(P))],'r--','LineWidth',1);

%     %%%%% show the orignal time series, t-x
%     figure('units','inches','position',[2 4 5 3]);
%     plot(t,x,'k-','LineWidth',1.5);hold on
%     plot(t,x_filt,'r-','LineWidth',1);
end
